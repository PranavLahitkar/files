#include<stdio.h>

void main()
{
	float salesAmount, commisionRate;
	printf("Enter Sales Amount:");
	scanf("%f",&salesAmount);
	printf("Enter Commision rate : ");
	scanf("%f",&commisionRate);
	
	float commision;
	commision = salesAmount*commisionRate/100;
	printf("Total Commision %f:",commision);
}
