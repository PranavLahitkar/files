#include<stdio.h>

float calculate_commision(float sales)
{
	if(sales<1000)
	{
		return 0.0;
	}
	else if(sales>=1000 && sales<=5000)
	{
		return 0.05*sales;
	}
	else if(sales>5000 && sales<=10000)
	{
		return 0.07*sales;
	}
	else
	{
		return 0.10*sales;
	}
}
int main()
{
	float sales_value, commision;
	printf("Enter the sales amount :");
	scanf("%f",&sales_value);
	
	commision = calculate_commision(sales_value);
	printf("The commision for %.2f sales is %.2f.",sales_value,commision);
	
	return 0;
}
