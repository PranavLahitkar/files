#include<stdio.h>

int is_leap_year(int year)
{
	if((year % 4==0 && year%100!=0)||(year % 400 == 0))
	{
		return 1;
	}
	return 0;
}

void next_date(int day, int month, int year)
{
	int days_in_month[] = {31,28,31,30,31,30,31,31,30,31,30,31};
	
	if(is_leap_year(year))
	{
		days_in_month[1]= 29;
	}
	
	if(month<1 || month>12 || day<1 || day>days_in_month[month-1])
	{
		printf("Invalid date\n");
		return ;
	}
	day++;
	
	if(day> days_in_month[month-1])
	{
		day=1;
		month++;
	}
	
	if(month>12)
	{
		month = 1;
		year++;
	}
	printf("Next date :%02d-%02d-%d\n",day,month,year);
}
int main()
{
	int day, month, year;
	
	printf("Enter day:");
	scanf("%d",&day);
	printf("Enter Month:");
	scanf("%d",&month);
	printf("Enter year:");
	scanf("%d",&year);
	
	next_date(day,month,year);
	return 0;
}
